﻿(function () {
    var div = document.createElement('div');
    div.classList.add('note');
    div.innerHTML = 'У вас новое сообщение';
    //export
    window.NotificationDiv = div;


})();