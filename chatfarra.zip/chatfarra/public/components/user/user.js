﻿(function () {
     
    class User {
        constructor(options) {
            this.name = options.name;
            this.photo = options.photo;
        }

        _lin() {

        }
       
    }

    

    //export
    window.User = User;


})();